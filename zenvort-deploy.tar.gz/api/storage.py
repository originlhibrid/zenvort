import boto3
from botocore.config import Config
from api.config import get_settings

_settings = None


def _get_s3_client():
    global _settings
    if _settings is None:
        _settings = get_settings()
    s3_client = boto3.client(
        's3',
        endpoint_url=f"https://{_settings.R2_ACCOUNT_ID}.r2.cloudflarestorage.com",
        aws_access_key_id=_settings.R2_ACCESS_KEY_ID,
        aws_secret_access_key=_settings.R2_SECRET_ACCESS_KEY,
        config=Config(
            signature_version='s3v4',
            s3={'addressing_style': 'path'}
        )
    )
    return s3_client


def upload_file(local_path: str, storage_key: str, content_type: str) -> None:
    _get_s3_client().upload_file(
        local_path,
        get_settings().R2_BUCKET_NAME,
        storage_key,
        ExtraArgs={"ContentType": content_type},
    )


def download_file(storage_key: str, local_path: str) -> None:
    _get_s3_client().download_file(get_settings().R2_BUCKET_NAME, storage_key, local_path)


def delete_file(storage_key: str) -> None:
    _get_s3_client().delete_object(Bucket=get_settings().R2_BUCKET_NAME, Key=storage_key)


def generate_download_url(storage_key: str, expires_seconds: int = 840) -> str:
    return _get_s3_client().generate_presigned_url(
        "get_object",
        Params={
            "Bucket": get_settings().R2_BUCKET_NAME,
            "Key": storage_key,
        },
        ExpiresIn=expires_seconds,
    )